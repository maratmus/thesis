.pdf files are needed if compiling a .pdf document
.eps files are needed if compiling a .dvi document